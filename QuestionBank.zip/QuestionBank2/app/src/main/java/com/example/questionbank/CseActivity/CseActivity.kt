package com.example.questionbank.CseActivity

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.questionbank.R

class CseActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cse)

        val button18 = findViewById<Button>(R.id.button18)
        button18.setOnClickListener {
            intent = Intent(this, Activity2018::class.java)
            startActivity(intent)
        }
        val button19 = findViewById<Button>(R.id.button19)
        button19.setOnClickListener {
            intent = Intent(this, Activity2019::class.java)
            startActivity(intent)
        }
        val button20 = findViewById<Button>(R.id.button20)
        button20.setOnClickListener {
            intent = Intent(this, Activity2020::class.java)
            startActivity(intent)
        }
        val button21 = findViewById<Button>(R.id.button21)
        button21.setOnClickListener {
            intent = Intent(this, Activity2021::class.java)
            startActivity(intent)
        }
        val button22 = findViewById<Button>(R.id.button22)
        button22.setOnClickListener {
            intent = Intent(this, Activity2022::class.java)
            startActivity(intent)
        }
    }
}